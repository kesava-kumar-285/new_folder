import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../login-service.service';
import emailjs, { EmailJSResponseStatus } from 'emailjs-com';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css'],
})
export class ForgotComponent implements OnInit {
  message: string = '';
  name: string;
  password: string;
  emailid: string;
  constructor(private loginService: LoginServiceService) {}

  ngOnInit(): void {}

  onClickSubmit(e: Event) {
    if (this.loginService.retrievePassword(this.emailid)) {
      emailjs
        .sendForm(
          'YOUR_SERVICE_ID',
          'YOUR_TEMPLATE_ID',
          e.target as HTMLFormElement,
          'YOUR_USER_ID'
        )
        .then(
          (result: EmailJSResponseStatus) => {
            console.log('Email sent');
            console.log(result.text);
          },
          (error) => {
            console.log('Error in sending mail');
            console.log(error.text);
          }
        );
    } else alert('Not found');
    this.emailid = '';
  }

  setFields() {
    if (this.loginService.retrievePassword(this.emailid)) {
      this.name = this.loginService.forgotUser.name;
      this.password = this.loginService.forgotUser.password;
      this.message = '';
    } else {
      this.message = 'Your email is not registered with us.';
    }
  }
}
