import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class MedicinesService {
  medicines: any = [];
  userEmail: string = undefined;

  constructor(private datePipe: DatePipe) {}

  sortById(type: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      temp.push(Object.assign({}, element));
    });

    if (type === 'asc')
      temp.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    else if (type === 'dsc')
      temp.sort((a, b) => (a.id > b.id ? -1 : a.id < b.id ? 1 : 0));

    return temp;
  }

  sortByName(type: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      temp.push(Object.assign({}, element));
    });

    if (type === 'asc')
      temp.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
    else if (type === 'dsc')
      temp.sort((a, b) => (a.name > b.name ? -1 : a.name < b.name ? 1 : 0));

    return temp;
  }

  sortByDate(type: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      temp.push(Object.assign({}, element));
    });

    if (type === 'asc')
      temp.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
    else if (type === 'dsc')
      temp.sort((a, b) => (a.date > b.date ? -1 : a.date < b.date ? 1 : 0));

    return temp;
  }

  sortByMedicine(type: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      temp.push(Object.assign({}, element));
    });

    if (type === 'asc')
      temp.sort((a, b) =>
        a.medicine < b.medicine ? -1 : a.medicine > b.medicine ? 1 : 0
      );
    else if (type === 'dsc')
      temp.sort((a, b) =>
        a.medicine > b.medicine ? -1 : a.medicine < b.medicine ? 1 : 0
      );

    return temp;
  }

  sortByAmount(type: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      temp.push(Object.assign({}, element));
    });

    if (type === 'asc')
      temp.sort((a, b) =>
        a.amount < b.amount ? -1 : a.amount > b.amount ? 1 : 0
      );
    else if (type === 'dsc')
      temp.sort((a, b) =>
        a.amount > b.amount ? -1 : a.amount < b.amount ? 1 : 0
      );

    return temp;
  }

  filterById(id: number): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      if ((element.id + '').includes(id + ''))
        temp.push(Object.assign({}, element));
    });
    return temp;
  }

  filterByName(namedata: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      if (element.name.toLowerCase().includes(namedata.toLowerCase()))
        temp.push(Object.assign({}, element));
    });
    return temp;
  }

  filterByDate(date: string): any[] {
    var temp = [];
    var dFilter;
    var iFilter = this.datePipe.transform(date, 'dd/MM/yyyy');
    this.medicines.forEach((element) => {
      dFilter = this.datePipe.transform(element.date, 'dd/MM/yyyy');
      if (dFilter === iFilter) temp.push(Object.assign({}, element));
    });
    return temp;
  }

  filterByMedicine(medicine: string): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      if (element.medicine[0].toLowerCase().includes(medicine.toLowerCase()))
        temp.push(Object.assign({}, element));
    });
    return temp;
  }

  filterByAmount(amount: number): any[] {
    var temp = [];
    this.medicines.forEach((element) => {
      if ((element.amount + '').includes(amount + ''))
        temp.push(Object.assign({}, element));
    });
    return temp;
  }
}
