function largest(n1, n2) {
    if (n1 < n2)
        return n1;
    else
        return n2;
}
console.log("Smallest is : " + largest(80, 100));
