function largest(n1, n2) {
    if (n1 > n2)
        return n1;
    else
        return n2;
}
console.log("Largest is : " + largest(10, 80));
