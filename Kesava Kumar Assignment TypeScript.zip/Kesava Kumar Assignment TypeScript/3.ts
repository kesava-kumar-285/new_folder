var a=8;
var b=10;

var add=a+b;
var sub=a-b;
var mult=a*b;
var div=a/b;
var rem=a%b;


console.log("Result : for 8 & 10");
console.log("ADD : "+add);
console.log("SUB : "+sub);
console.log("MULT : "+mult);
console.log("DIV : "+div);
console.log("REM : "+rem);

