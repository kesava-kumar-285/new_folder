var num = 80;
var result = num >= 0 ? (num == 0 ? "zero" : "positive") : "negative";
console.log(result);
