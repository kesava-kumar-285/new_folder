var name1:string ="Kesava Kumar";
//var Engineering_stream:string="CSE";
/*var view:string="Those days were so memerobale,
 we enjoyed a lot and can't go back";*/

console.log("Name : "+name1);
//console.log("Engineering_stream : "+ Engineering_stream);
//console.log("View : " + view);