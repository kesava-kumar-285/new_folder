var string1=" This training is about ";
var string2="TypeScript";

console.log("Concatenation of two strings : " + (string1+string2));