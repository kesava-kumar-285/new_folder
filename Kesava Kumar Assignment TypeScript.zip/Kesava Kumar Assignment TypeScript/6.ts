var num = 10;

(num%2==0)? console.log( "Number : " +num +" is even"):
    console.log( "Number : " +num +" is odd");                                         