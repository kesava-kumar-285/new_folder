var a=18;
	
if (a>=18)
	console.log("The candidate is eligible for voting");  
else
	console.log("The candidate is not eligible for voting");  

                                                                                       