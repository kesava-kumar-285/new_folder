
function smallest (n1: number, n2: number) :number
{
	if (n1<n2)
		return n1;
	else
		return n2;
}

console.log("Smallest is : "+smallest(80,100)); 