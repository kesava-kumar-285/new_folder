
public class WebSecurityConfig {

}
