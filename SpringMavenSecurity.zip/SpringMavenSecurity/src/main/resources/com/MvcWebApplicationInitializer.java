package com;
public class MvcWebApplicationInitializer extends AbstarctAnnotationConfigDispacterServletInitializer {
	@Override
	protected Class<?>[] getRootConfigClasses(){
		return new Class[] { WebSecuirtyConfig.class};
	}
	
	@Override
	protected Class<?>[] getServeletConfigClasses() {
		return null;
	}
	
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}
	
}
