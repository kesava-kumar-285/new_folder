var myData = [80, "CSE Dept"];
console.log("Age is :" + myData[0]);
console.log("Age is :" + myData[1]);
