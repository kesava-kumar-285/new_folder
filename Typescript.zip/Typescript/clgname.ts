var clgname:any= "amrita university";
var age:any=80;
console.log(clgname);
console.log(age);