function even(n:number){
var i:number =0;

for(i=0;i<n;i++){
	if(i%2==0){
		console.log(i)
		}
		}
}
even(20);