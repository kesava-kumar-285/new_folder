var clgname = "amrita university";
var age = 80;
console.log(clgname);
console.log(age);
