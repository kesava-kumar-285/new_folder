export interface student_interface{
	assign_data(id:number,name:string,stream:string):void;
	//display():void;
	get_Id();
	get_Name();
	get_Stream();
	
	}