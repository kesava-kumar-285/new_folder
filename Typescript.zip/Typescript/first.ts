var name1:string ="My name is kesava";
console.log(name1);