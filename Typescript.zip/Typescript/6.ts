var employee = [80, "chandra", "cse", "data scientist", 8800000];
console.log(employee);
employee[1] ="chetan";
console.log(employee);