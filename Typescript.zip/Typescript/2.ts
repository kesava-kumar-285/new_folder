var a:number =10;
var n:number =1;
while(a!=1){
	n=n*a;
	a--;
	}
console.log(n);