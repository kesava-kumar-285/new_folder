var a = 10;
var n = 1;
while (a != 1) {
    n = n * a;
    a--;
}
console.log(n);
