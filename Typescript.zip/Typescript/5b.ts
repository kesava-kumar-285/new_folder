function factorial(n:number){
var a:number =n;
var n:number =1;
while(a!=1){
	n=n*a;
	a--;
	}
console.log(n);
}
factorial(10);